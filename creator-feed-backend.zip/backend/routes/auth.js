
const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const User = require("../models/User");
const router = express.Router();

router.post("/register", async (req, res) => {
  const { username, email, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  const user = new User({ username, email, password: hashed });
  await user.save();
  res.send("Registered");
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user || !(await bcrypt.compare(password, user.password))) return res.status(403).send("Invalid");
  const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET);
  user.lastLoginDate = new Date();
  user.credits += 10;
  await user.save();
  res.json({ token });
});

module.exports = router;
