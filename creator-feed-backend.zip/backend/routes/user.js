
const express = require("express");
const User = require("../models/User");
const jwt = require("jsonwebtoken");
const router = express.Router();

function auth(req, res, next) {
  const token = req.headers.authorization;
  if (!token) return res.status(401).send("Unauthorized");
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(403).send("Forbidden");
  }
}

router.get("/me", auth, async (req, res) => {
  const user = await User.findById(req.user.id);
  res.json(user);
});

router.post("/complete-profile", auth, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user.profileCompleted) user.credits += 50;
  user.profileCompleted = true;
  await user.save();
  res.send("Profile updated");
});

router.post("/save-feed", auth, async (req, res) => {
  const user = await User.findById(req.user.id);
  const { postId } = req.body;
  if (!user.savedFeeds.includes(postId)) user.savedFeeds.push(postId);
  user.credits += 5;
  await user.save();
  res.send("Feed saved");
});

router.get("/admin/users", auth, async (req, res) => {
  if (req.user.role !== "Admin") return res.status(403).send("Admin only");
  const users = await User.find();
  res.json(users);
});

module.exports = router;
