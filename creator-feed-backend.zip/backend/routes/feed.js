
const express = require("express");
const axios = require("axios");
const router = express.Router();

router.get("/reddit", async (req, res) => {
  const reddit = await axios.get("https://www.reddit.com/r/popular.json");
  const posts = reddit.data.data.children.map(post => ({
    id: post.data.id,
    title: post.data.title,
    url: post.data.url
  }));
  res.json(posts);
});

router.get("/mock-linkedin", (req, res) => {
  const mockPosts = [
    { id: "1", title: "LinkedIn Post A", url: "https://linkedin.com/mock/a" },
    { id: "2", title: "LinkedIn Post B", url: "https://linkedin.com/mock/b" }
  ];
  res.json(mockPosts);
});

module.exports = router;
