
const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  role: { type: String, enum: ["User", "Admin"], default: "User" },
  credits: { type: Number, default: 0 },
  profileCompleted: { type: Boolean, default: false },
  lastLoginDate: Date,
  savedFeeds: [String],
  activityLog: [String]
});
module.exports = mongoose.model("User", UserSchema);
